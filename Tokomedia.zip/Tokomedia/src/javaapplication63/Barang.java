package javaapplication63;

import java.util.Random;

class Barang {
    private String no_resi;
    private String nama_barang;
    private String deskripsi_barang;
    private String status_barang;
    private String kota_tujuan;
    private Pengirim sender;

    public Barang(String nama_barang, String deskripsi_barang, String status_barang, String kota_tujuan) {
        Random random = new Random();
        int nomor = random.nextInt(1000000000);
        this.no_resi = String.valueOf(nomor);
        this.nama_barang = nama_barang;
        this.deskripsi_barang = deskripsi_barang;
        this.status_barang = status_barang;
        this.kota_tujuan = kota_tujuan;
    }

    public void setSender(Pengirim sender) {
        this.sender = sender;
    }

    public void setNo_resi(String no_resi) {
        this.no_resi = no_resi;
    }
    
    public void setStatus_barang(String status_barang) {
        this.status_barang = status_barang;
    }
    
    public String getNo_resi() {
        return no_resi;
    }

    public String getNama_barang() {
        return nama_barang;
    }

    public String getDeskripsi_barang() {
        return deskripsi_barang;
    }

    public String getStatus_barang() {
        return status_barang;
    }

    public String getKota_tujuan() {
        return kota_tujuan;
    }

    public Pengirim getSender() {
        return sender;
    }
    
}

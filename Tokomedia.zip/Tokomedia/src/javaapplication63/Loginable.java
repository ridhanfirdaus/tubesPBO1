package javaapplication63;

public interface Loginable {
    public boolean login(String nama, String password);
    public void edit_profil(String nama, String password);
}

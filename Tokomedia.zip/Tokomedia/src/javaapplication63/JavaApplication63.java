package javaapplication63;

import java.sql.*;
import java.util.Random;

public class JavaApplication63 {
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        Login mainframe = new Login();
        mainframe.setVisible(true);
    }
}

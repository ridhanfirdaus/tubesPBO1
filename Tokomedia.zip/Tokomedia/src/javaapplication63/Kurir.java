package javaapplication63;

class Kurir implements Loginable {
    private int idKurir;
    private String nama_kurir;
    private String password;
    private Pengirim sender;

    public Kurir(String nama, String password) {
        this.nama_kurir = nama;
        this.password = password;
    }

    public void setIdKurir(int idKurir) {
        this.idKurir = idKurir;
    }

    public int getIdKurir() {
        return idKurir;
    }
    
    public void setSender(Pengirim sender) {
        this.sender = sender;
    }
    public Pengirim getSender() {
        return sender;
    }

    public String getNama_kurir() {
        return nama_kurir;
    }

    public String getPassword() {
        return password;
    }
    
    @Override
    public boolean login(String nama, String password) {
        if (nama.equals(this.nama_kurir) && password.equals(this.password)) {
            this.nama_kurir = nama;
            this.password = password;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void edit_profil(String nama, String password) {
        this.nama_kurir = nama;
        this.password = password;
    }
}

package javaapplication63;

import java.util.ArrayList;

public class Admin implements Loginable{
    private String nama_admin;
    private String password;
    private ArrayList<Kurir> listKurir;
    private ArrayList<Pengirim> listPengirim;

    public Admin(String nama_admin, String password) {
        this.nama_admin = nama_admin;
        this.password = password;
        listKurir = new ArrayList<>();
        listPengirim = new ArrayList<>();
    }
    
    public void setListKurir(ArrayList<Kurir> listKurir) {
        this.listKurir = listKurir;
    }

    public void setListPengirim(ArrayList<Pengirim> listPengirim) {
        this.listPengirim = listPengirim;
    }
    
    public ArrayList<Kurir> getListKurir() {
        return listKurir;
    }

    public ArrayList<Pengirim> getListPengirim() {
        return listPengirim;
    }
    
    public String getNama_admin() {
        return nama_admin;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public boolean login(String nama, String password) {
        if (nama.equals(this.nama_admin) && password.equals(this.password)) {
            this.nama_admin = nama;
            this.password = password;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void edit_profil(String nama, String password) {
        this.nama_admin = nama;
        this.password = password;
    }
}

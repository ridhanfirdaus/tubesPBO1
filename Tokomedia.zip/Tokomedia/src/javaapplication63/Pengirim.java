package javaapplication63;

import java.util.ArrayList;

class Pengirim implements Loginable{
    private int idPengirim;
    private String nama_pengirim;
    private String password;
    private ArrayList<Barang> listBarang;

    // konstruktor dengan parameter idPengirim, nama_pengirim, dan password
    public Pengirim(String nama, String password) {
        this.nama_pengirim = nama;
        this.password = password;
        this.listBarang = new ArrayList<>();
    }

    public void setIdPengirim(int idPengirim) {
        this.idPengirim = idPengirim;
    }
    
    public void tambahBarang(Barang barang){
        this.listBarang.add(barang);
    }

    public void setListBarang(ArrayList<Barang> listBarang) {
        this.listBarang = listBarang;
    }

    public int getIdPengirim() {
        return idPengirim;
    }

    public String getNama_pengirim() {
        return nama_pengirim;
    }

    public String getPassword() {
        return password;
    }

    public ArrayList<Barang> getListBarang() {
        return listBarang;
    }
    
    @Override
    public boolean login(String nama, String password) {
        if (nama.equals(this.nama_pengirim) && password.equals(this.password)) {
            this.nama_pengirim = nama;
            this.password = password;
            return true;
        } else {
            return false;
        }
    }
    
    @Override
    public void edit_profil(String nama, String password) {
        this.nama_pengirim = nama;
        this.password = password;
    }
}
